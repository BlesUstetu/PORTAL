import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase().trim();
  const adminPassword = process.env.ADMIN_PASSWORD || "Admin12345!";
  const adminName = process.env.ADMIN_NAME || "Admin";

  const exists = await prisma.user.findUnique({ where: { email: adminEmail } });

  if (!exists) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.create({
      data: {
        fullName: adminName,
        email: adminEmail,
        passwordHash,
        phone: "0000000000",
        role: "ADMIN",
        status: "ACTIVE"
      }
    });
    console.log("Seeded admin:", adminEmail);
    console.log("Admin password:", adminPassword);
  } else {
    console.log("Admin already exists:", adminEmail);
  }

  // Seed minimal published content (optional)
  const eventSlug = "welcome-meetup";
  const event = await prisma.event.findUnique({ where: { slug: eventSlug } });
  if (!event) {
    await prisma.event.create({
      data: {
        title: "Welcome Meetup",
        slug: eventSlug,
        description: "Acara perkenalan anggota baru dan pengumuman agenda komunitas.",
        location: "Online",
        dateStart: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        quota: 100,
        isPublished: true
      }
    });
  }

  const postSlug = "pembaruan-pertama";
  const post = await prisma.newsPost.findUnique({ where: { slug: postSlug } });
  if (!post) {
    await prisma.newsPost.create({
      data: {
        title: "Pembaruan Pertama",
        slug: postSlug,
        excerpt: "Selamat datang di portal komunitas. Ini adalah posting pembaruan pertama.",
        content: "Ini adalah contoh konten berita. Admin dapat mengubah dan menambahkan berita melalui Admin Panel.",
        category: "Update",
        isPublished: true,
        publishedAt: new Date()
      }
    });
  }

  console.log("Seed completed.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
