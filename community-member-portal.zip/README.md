# Community Member Portal (Next.js + Prisma + NextAuth)

Portal komunitas untuk:
- Penyebaran informasi (Berita, Prestasi, Beasiswa, Donasi)
- Keterlibatan komunitas (Event list + detail, registrasi **member-only**)
- Perekrutan anggota (Join form -> **langsung aktif**)
- Login aman anggota (Credentials + hashed password)

Dokumentasi referensi:
- Next.js App Router citeturn0search0turn0search8
- NextAuth Credentials Provider citeturn0search1turn0search5
- Prisma Postgres Quickstart citeturn0search2turn0search6
- Tailwind Next.js Guide citeturn0search3turn0search7

---

## 1) Instalasi

### Prasyarat
- Node.js 18+ (disarankan 20+)
- PostgreSQL database (local / Supabase / Neon / Railway)

### Langkah
1. Copy env:
   - `cp .env.example .env`
   - isi `DATABASE_URL`, `NEXTAUTH_SECRET`

2. Install:
   - `npm install`

3. Prisma:
   - `npx prisma generate`
   - `npx prisma migrate dev --name init`

4. Seed admin + konten contoh:
   - `npm run prisma:seed`

5. Jalankan:
   - `npm run dev`
   - buka `http://localhost:3000`

---

## 2) Akun Admin
Default dari seed:
- Email: `admin@example.com`
- Password: `Admin12345!`

Ubah melalui env:
- `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`

---

## 3) Jalur Customisasi (Logo, Nama Organisasi, Kontak)

### A. Logo & Icon
- Logo: `public/logo.svg`  (ganti file ini)
- Favicon: `public/favicon.ico` (isi favicon Anda)

### B. Nama organisasi & identitas situs
Edit file:
- `lib/site.ts`
  - `siteName` (judul portal)
  - `organizationName` (nama komunitas/perusahaan)
  - `tagline` (deskripsi singkat)
  - `contactEmail` (email kontak)
  - `footerNote` (catatan footer)

### C. Warna / Tema
Edit:
- `app/globals.css` (kelas utilitas tombol, background, dll)

---

## 4) Modul yang Sudah Jadi (Sesuai Kebutuhan)
### Publik
- Home: `/`
- Berita: `/news`
- Prestasi: `/achievements`
- Beasiswa: `/scholarships` + apply form
- Donasi: `/donations` + form konfirmasi
- Acara (lihat): `/events`, `/events/[slug]`

### Anggota (butuh login)
- Dashboard: `/member/dashboard`
- Event saya: `/member/events`
- Profil: `/member/profile`

### Admin (butuh role ADMIN)
- Admin dashboard: `/admin/dashboard`
- Kelola event: `/admin/events`
- Lihat peserta + export CSV: `/admin/events/[id]/registrations`

Catatan:
- Registrasi event **server-side protected** via `POST /api/events/[id]/register`

---

## 5) Deployment
- Frontend + API: Vercel
- Database: Supabase/Neon/Railway
- Set env di hosting sesuai `.env.example`

---

## 6) Fitur Lanjutan yang mudah ditambahkan
- Admin panel untuk News/Scholarships/Achievements/Donations
- Upload dokumen beasiswa (S3/Cloudinary)
- Email notifikasi (welcome, event confirmation) via Resend/SMTP
- Reset password + MFA admin

