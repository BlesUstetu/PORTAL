import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/options";

export async function requireSession() {
  const session = await getServerSession(authOptions);
  const user = (session as any)?.user;
  if (!user) return { ok: false as const, status: 401 as const, user: null };
  return { ok: true as const, status: 200 as const, user };
}

export async function requireAdmin() {
  const s = await requireSession();
  if (!s.ok) return s;
  if (s.user.role !== "ADMIN") return { ok: false as const, status: 403 as const, user: s.user };
  return s;
}
