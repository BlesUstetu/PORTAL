export const site = {
  siteName: "Community Portal",
  organizationName: "Your Organization",
  tagline: "Informasi, keterlibatan komunitas, dan perekrutan anggota.",
  logoPath: "/logo.svg",
  contactEmail: "info@your-org.org",
  footerNote: "© {year} Your Organization"
};
