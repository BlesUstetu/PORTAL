import { z } from "zod";

export const adminEventSchema = z.object({
  title: z.string().min(3).max(120),
  slug: z.string().min(3).max(120).regex(/^[a-z0-9-]+$/, "Slug hanya boleh a-z 0-9 dan '-'"),
  description: z.string().min(10).max(5000),
  location: z.string().max(120).optional().or(z.literal("")),
  dateStart: z.string().refine((v) => !Number.isNaN(Date.parse(v)), { message: "dateStart invalid" }),
  dateEnd: z.string().optional().or(z.literal("")).refine((v) => !v || !Number.isNaN(Date.parse(v)), { message: "dateEnd invalid" }),
  quota: z.number().int().min(0).max(100000),
  isPublished: z.boolean()
});
