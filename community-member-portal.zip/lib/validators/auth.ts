import { z } from "zod";

export const registerSchema = z.object({
  fullName: z.string().min(3, "Minimal 3 karakter").max(80),
  email: z.string().email("Email tidak valid").max(120),
  password: z.string().min(8, "Minimal 8 karakter").max(72),
  phone: z.string().min(10, "Minimal 10 digit").max(15),
  city: z.string().max(60).optional().or(z.literal("")),
  address: z.string().max(200).optional().or(z.literal("")),
  dateOfBirth: z
    .string()
    .optional()
    .or(z.literal(""))
    .refine((v) => !v || !Number.isNaN(Date.parse(v)), { message: "Tanggal lahir tidak valid" })
});
