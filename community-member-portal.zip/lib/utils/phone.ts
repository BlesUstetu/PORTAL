export function normalizePhone(input: string) {
  return input.replace(/[\s-]/g, "");
}
