import Link from "next/link";

export function EventCard({ event }: { event: any }) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-base font-extrabold">{event.title}</div>
          <div className="mt-1 text-sm text-neutral-600">
            {new Date(event.dateStart).toLocaleString()} • {event.location || "TBA"}
          </div>
        </div>
        <Link className="btn btn-outline" href={`/events/${event.slug}`}>
          Detail
        </Link>
      </div>
    </div>
  );
}
