"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useSearchParams } from "next/navigation";

export default function LoginForm() {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const searchParams = useSearchParams();
  const next = searchParams.get("next") || "/member/dashboard";

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setErr(null);

    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") || "");
    const password = String(form.get("password") || "");

    const res = await signIn("credentials", { email, password, redirect: false });

    if (!res?.ok) {
      setErr("Login gagal. Periksa email/password.");
      setLoading(false);
      return;
    }

    window.location.href = next;
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {err ? <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{err}</div> : null}

      <div>
        <div className="label mb-1">Email</div>
        <input name="email" type="email" className="input" required />
      </div>

      <div>
        <div className="label mb-1">Password</div>
        <input name="password" type="password" className="input" required />
      </div>

      <button disabled={loading} className="btn btn-primary w-full">
        {loading ? "Memproses..." : "Login"}
      </button>
    </form>
  );
}
