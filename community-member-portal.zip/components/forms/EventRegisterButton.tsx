"use client";

import { useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";

export default function EventRegisterButton({ eventId }: { eventId: string }) {
  const { data: session } = useSession();
  const user = (session as any)?.user;
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function register() {
    setLoading(true);
    setMsg(null);
    const res = await fetch(`/api/events/${eventId}/register`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      setMsg(data?.error || "Gagal daftar event");
      setLoading(false);
      return;
    }
    setMsg("Berhasil terdaftar. Cek dashboard Anda.");
    setLoading(false);
  }

  if (!user) {
    return (
      <Link href={`/login?next=${encodeURIComponent(window.location.pathname)}`} className="btn btn-primary">
        Login untuk mendaftar
      </Link>
    );
  }

  return (
    <div className="space-y-2">
      <button disabled={loading} onClick={register} className="btn btn-primary">
        {loading ? "Memproses..." : "Daftar Event (Member Only)"}
      </button>
      {msg ? <div className="text-sm text-neutral-700">{msg}</div> : null}
    </div>
  );
}
