"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";

export default function JoinForm() {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(null);
    setLoading(true);

    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok) {
      setErr(data?.error || "Gagal daftar");
      setLoading(false);
      return;
    }

    // Auto-login
    const email = String(payload.email || "");
    const password = String(payload.password || "");
    await signIn("credentials", { email, password, callbackUrl: "/member/dashboard" });
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {err ? <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{err}</div> : null}

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <div className="label mb-1">Nama lengkap *</div>
          <input name="fullName" className="input" placeholder="Nama sesuai identitas" required />
        </div>
        <div>
          <div className="label mb-1">No HP/WhatsApp *</div>
          <input name="phone" className="input" placeholder="08xxxxxxxxxx" required />
        </div>
        <div>
          <div className="label mb-1">Email *</div>
          <input name="email" type="email" className="input" placeholder="nama@email.com" required />
        </div>
        <div>
          <div className="label mb-1">Password *</div>
          <input name="password" type="password" className="input" placeholder="Minimal 8 karakter" required />
        </div>

        <div>
          <div className="label mb-1">Kota (opsional)</div>
          <input name="city" className="input" placeholder="Jakarta" />
        </div>
        <div>
          <div className="label mb-1">Tanggal lahir (opsional)</div>
          <input name="dateOfBirth" type="date" className="input" />
        </div>

        <div className="md:col-span-2">
          <div className="label mb-1">Alamat (opsional)</div>
          <input name="address" className="input" placeholder="Alamat lengkap" />
        </div>
      </div>

      <button disabled={loading} className="btn btn-primary w-full">
        {loading ? "Memproses..." : "Daftar Anggota"}
      </button>

      <p className="text-xs text-neutral-500">
        Dengan mendaftar, Anda menyetujui kebijakan privasi dan syarat & ketentuan komunitas.
      </p>
    </form>
  );
}
