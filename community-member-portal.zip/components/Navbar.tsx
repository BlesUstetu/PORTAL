"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { site } from "@/lib/site";

export default function Navbar() {
  const { data: session, status } = useSession();
  const user = (session as any)?.user;

  return (
    <header className="border-b border-neutral-200 bg-white/80 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={site.logoPath} alt="logo" className="h-8 w-8" />
          <div className="leading-tight">
            <div className="text-sm font-extrabold">{site.siteName}</div>
            <div className="text-xs text-neutral-500">{site.organizationName}</div>
          </div>
        </Link>

        <nav className="flex items-center gap-3 text-sm">
          <Link href="/news" className="hover:underline">Berita</Link>
          <Link href="/events" className="hover:underline">Acara</Link>
          <Link href="/achievements" className="hover:underline">Prestasi</Link>
          <Link href="/scholarships" className="hover:underline">Beasiswa</Link>
          <Link href="/donations" className="hover:underline">Donasi</Link>

          {status === "loading" ? null : user ? (
            <>
              <Link href="/member/dashboard" className="btn btn-outline">Dashboard</Link>
              {(user.role === "ADMIN") && (
                <Link href="/admin/dashboard" className="btn btn-outline">Admin</Link>
              )}
              <button
                className="btn btn-primary"
                onClick={() => signOut({ callbackUrl: "/" })}
              >
                Keluar
              </button>
            </>
          ) : (
            <>
              <Link href="/join" className="btn btn-outline">Daftar Anggota</Link>
              <Link href="/login" className="btn btn-primary">Login</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
