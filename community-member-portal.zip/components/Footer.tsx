import { site } from "@/lib/site";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-neutral-200 bg-white">
      <div className="container py-10">
        <div className="grid gap-6 md:grid-cols-3">
          <div className="space-y-2">
            <div className="text-sm font-extrabold">{site.organizationName}</div>
            <p className="text-sm text-neutral-600">{site.tagline}</p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="font-semibold">Kontak</div>
            <div className="text-neutral-600">{site.contactEmail}</div>
          </div>
          <div className="space-y-2 text-sm">
            <div className="font-semibold">Legal</div>
            <div className="text-neutral-600">Kebijakan Privasi • Syarat & Ketentuan</div>
          </div>
        </div>
        <div className="muted mt-8 text-xs">
          {site.footerNote.replace("{year}", String(year))}
        </div>
      </div>
    </footer>
  );
}
