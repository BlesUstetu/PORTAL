import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/options";

export default async function MemberDashboard() {
  const session = await getServerSession(authOptions);
  const user = (session as any)?.user;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Dashboard Anggota</h1>
      <div className="card p-6">
        <div className="text-sm font-bold">Akun</div>
        <div className="mt-2 text-sm text-neutral-700">
          <div>Nama: {user?.name}</div>
          <div>Email: {user?.email}</div>
          <div>Status: {user?.status}</div>
          <div>Role: {user?.role}</div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="card p-6">
          <div className="text-sm font-extrabold">Akses Member-only</div>
          <p className="mt-2 text-sm text-neutral-600">
            Anda dapat mendaftar event melalui halaman detail acara.
          </p>
        </div>
        <div className="card p-6">
          <div className="text-sm font-extrabold">Riwayat</div>
          <p className="mt-2 text-sm text-neutral-600">
            Lihat riwayat pendaftaran event di menu “Event Saya”.
          </p>
        </div>
      </div>
    </div>
  );
}
