import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/options";
import { prisma } from "@/lib/db/prisma";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const session = await getServerSession(authOptions);
  const user = (session as any)?.user;

  const dbUser = await prisma.user.findUnique({
    where: { email: String(user.email) },
    select: { fullName: true, email: true, phone: true, city: true, address: true, dateOfBirth: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Profil</h1>
      <div className="card p-6">
        <div className="grid gap-2 text-sm text-neutral-700">
          <div><span className="font-semibold">Nama:</span> {dbUser?.fullName}</div>
          <div><span className="font-semibold">Email:</span> {dbUser?.email}</div>
          <div><span className="font-semibold">No HP:</span> {dbUser?.phone}</div>
          <div><span className="font-semibold">Kota:</span> {dbUser?.city || "-"}</div>
          <div><span className="font-semibold">Alamat:</span> {dbUser?.address || "-"}</div>
          <div><span className="font-semibold">Tanggal lahir:</span> {dbUser?.dateOfBirth ? new Date(dbUser.dateOfBirth).toLocaleDateString() : "-"}</div>
        </div>
        <p className="mt-4 text-xs text-neutral-500">
          Edit profil dapat ditambahkan sebagai fitur lanjutan (endpoint PATCH /api/member/profile).
        </p>
      </div>
    </div>
  );
}
