"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function MyEventsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/member/registrations")
      .then((r) => r.json())
      .then((d) => setItems(d.registrations || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Event Saya</h1>

      {loading ? <div className="muted">Memuat...</div> : null}

      <div className="grid gap-4">
        {items.map((r) => (
          <div key={r.id} className="card p-6">
            <div className="text-lg font-extrabold">{r.event.title}</div>
            <div className="mt-1 text-sm text-neutral-600">
              {new Date(r.event.dateStart).toLocaleString()} • {r.event.location || "TBA"}
            </div>
            <Link href={`/events/${r.event.slug}`} className="mt-3 inline-block text-sm underline">
              Lihat Detail
            </Link>
          </div>
        ))}
        {!loading && items.length === 0 ? <div className="muted">Anda belum mendaftar event.</div> : null}
      </div>
    </div>
  );
}
