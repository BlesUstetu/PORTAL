import Link from "next/link";

export default function MemberLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="space-y-6">
      <div className="card p-4">
        <div className="flex flex-wrap gap-3 text-sm">
          <Link href="/member/dashboard" className="btn btn-outline">Dashboard</Link>
          <Link href="/member/events" className="btn btn-outline">Event Saya</Link>
          <Link href="/member/profile" className="btn btn-outline">Profil</Link>
        </div>
      </div>
      {children}
    </div>
  );
}
