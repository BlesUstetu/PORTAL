import Link from "next/link";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="space-y-6">
      <div className="card p-4">
        <div className="flex flex-wrap gap-3 text-sm">
          <Link href="/admin/dashboard" className="btn btn-outline">Admin Dashboard</Link>
          <Link href="/admin/events" className="btn btn-outline">Kelola Event</Link>
        </div>
      </div>
      {children}
    </div>
  );
}
