"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function AdminEventsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/events");
    const data = await res.json();
    setItems(data.events || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function del(id: string) {
    if (!confirm("Hapus event ini?")) return;
    await fetch(`/api/admin/events/${id}`, { method: "DELETE" });
    await load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-black">Kelola Event</h1>
        <Link href="/admin/events/new" className="btn btn-primary">Buat Event</Link>
      </div>

      {loading ? <div className="muted">Memuat...</div> : null}

      <div className="grid gap-4">
        {items.map((e) => (
          <div key={e.id} className="card p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="text-lg font-extrabold">{e.title}</div>
                <div className="mt-1 text-sm text-neutral-600">
                  {new Date(e.dateStart).toLocaleString()} • Kuota: {e.quota} • {e.isPublished ? "PUBLISHED" : "DRAFT"}
                </div>
                <div className="mt-1 text-xs text-neutral-500">Slug: {e.slug}</div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link href={`/admin/events/${e.id}/edit`} className="btn btn-outline">Edit</Link>
                <Link href={`/admin/events/${e.id}/registrations`} className="btn btn-outline">Peserta</Link>
                <button onClick={() => del(e.id)} className="btn btn-primary">Hapus</button>
              </div>
            </div>
          </div>
        ))}
        {!loading && items.length === 0 ? <div className="muted">Belum ada event.</div> : null}
      </div>
    </div>
  );
}
