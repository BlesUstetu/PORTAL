"use client";

import { useState } from "react";

export default function NewEventPage() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);

    const form = new FormData(e.currentTarget);
    const payload: any = Object.fromEntries(form.entries());
    payload.quota = Number(payload.quota);
    payload.isPublished = payload.isPublished === "on";

    const res = await fetch("/api/admin/events", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok) {
      setMsg(data?.error || "Gagal membuat event");
      setLoading(false);
      return;
    }

    window.location.href = "/admin/events";
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-black">Buat Event</h1>
      <div className="card p-6">
        <form onSubmit={onSubmit} className="space-y-4">
          {msg ? <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div> : null}

          <div>
            <div className="label mb-1">Judul *</div>
            <input className="input" name="title" required />
          </div>

          <div>
            <div className="label mb-1">Slug (a-z 0-9 -) *</div>
            <input className="input" name="slug" placeholder="contoh: event-2026" required />
          </div>

          <div>
            <div className="label mb-1">Deskripsi *</div>
            <textarea className="input" name="description" rows={6} required />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="label mb-1">Lokasi</div>
              <input className="input" name="location" placeholder="Online / Gedung ..." />
            </div>
            <div>
              <div className="label mb-1">Kuota *</div>
              <input className="input" name="quota" type="number" min="0" defaultValue="0" required />
            </div>
            <div>
              <div className="label mb-1">Mulai *</div>
              <input className="input" name="dateStart" type="datetime-local" required />
            </div>
            <div>
              <div className="label mb-1">Selesai</div>
              <input className="input" name="dateEnd" type="datetime-local" />
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="isPublished" />
            Publish sekarang
          </label>

          <button disabled={loading} className="btn btn-primary w-full">
            {loading ? "Menyimpan..." : "Simpan"}
          </button>
        </form>
      </div>
    </div>
  );
}
