"use client";

import { useEffect, useState } from "react";

export default function EditEventPage({ params }: { params: { id: string } }) {
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetch("/api/admin/events")
      .then((r) => r.json())
      .then((d) => {
        const found = (d.events || []).find((x: any) => x.id === params.id);
        setData(found || null);
      })
      .finally(() => setLoading(false));
  }, [params.id]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);

    const form = new FormData(e.currentTarget);
    const payload: any = Object.fromEntries(form.entries());
    payload.quota = Number(payload.quota);
    payload.isPublished = payload.isPublished === "on";

    const res = await fetch(`/api/admin/events/${params.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const r = await res.json();
    if (!res.ok) {
      setMsg(r?.error || "Gagal update");
      return;
    }
    window.location.href = "/admin/events";
  }

  if (loading) return <div className="muted">Memuat...</div>;
  if (!data) return <div className="muted">Event tidak ditemukan.</div>;

  const toLocal = (iso: string) => {
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-black">Edit Event</h1>
      <div className="card p-6">
        <form onSubmit={onSubmit} className="space-y-4">
          {msg ? <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div> : null}

          <div>
            <div className="label mb-1">Judul *</div>
            <input className="input" name="title" defaultValue={data.title} required />
          </div>

          <div>
            <div className="label mb-1">Slug *</div>
            <input className="input" name="slug" defaultValue={data.slug} required />
          </div>

          <div>
            <div className="label mb-1">Deskripsi *</div>
            <textarea className="input" name="description" rows={6} required placeholder="Isi deskripsi lengkap event." />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="label mb-1">Lokasi</div>
              <input className="input" name="location" placeholder="Online / Gedung ..." />
            </div>
            <div>
              <div className="label mb-1">Kuota *</div>
              <input className="input" name="quota" type="number" min="0" defaultValue={String(data.quota)} required />
            </div>
            <div>
              <div className="label mb-1">Mulai *</div>
              <input className="input" name="dateStart" type="datetime-local" defaultValue={toLocal(data.dateStart)} required />
            </div>
            <div>
              <div className="label mb-1">Selesai</div>
              <input className="input" name="dateEnd" type="datetime-local" />
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="isPublished" defaultChecked={!!data.isPublished} />
            Published
          </label>

          <button className="btn btn-primary w-full">Simpan Perubahan</button>
          <p className="text-xs text-neutral-500">
            Catatan: halaman edit ini minimal. Untuk deskripsi & lokasi, silakan isi ulang.
          </p>
        </form>
      </div>
    </div>
  );
}
