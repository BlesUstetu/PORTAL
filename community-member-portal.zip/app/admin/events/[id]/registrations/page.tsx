"use client";

import { useEffect, useState } from "react";

export default function RegistrationsPage({ params }: { params: { id: string } }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/admin/events/${params.id}/registrations`)
      .then((r) => r.json())
      .then((d) => setRows(d.registrations || []))
      .finally(() => setLoading(false));
  }, [params.id]);

  function exportCsv() {
    const header = ["createdAt","fullName","email","phone","city"];
    const lines = [header.join(",")].concat(
      rows.map((r) => {
        const u = r.user;
        const vals = [
          new Date(r.createdAt).toISOString(),
          u.fullName || "",
          u.email || "",
          u.phone || "",
          u.city || ""
        ].map((v: string) => `"${String(v).replace(/"/g, '""')}"`);
        return vals.join(",");
      })
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `registrations-${params.id}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-black">Peserta Event</h1>
        <button onClick={exportCsv} className="btn btn-primary">Export CSV</button>
      </div>

      {loading ? <div className="muted">Memuat...</div> : null}

      <div className="card p-6 overflow-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-neutral-500">
            <tr>
              <th className="py-2">Waktu</th>
              <th className="py-2">Nama</th>
              <th className="py-2">Email</th>
              <th className="py-2">No HP</th>
              <th className="py-2">Kota</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, idx) => (
              <tr key={idx} className="border-t border-neutral-200">
                <td className="py-2">{new Date(r.createdAt).toLocaleString()}</td>
                <td className="py-2">{r.user.fullName}</td>
                <td className="py-2">{r.user.email}</td>
                <td className="py-2">{r.user.phone}</td>
                <td className="py-2">{r.user.city || "-"}</td>
              </tr>
            ))}
            {!loading && rows.length === 0 ? (
              <tr><td className="py-3 text-neutral-500" colSpan={5}>Belum ada peserta.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
