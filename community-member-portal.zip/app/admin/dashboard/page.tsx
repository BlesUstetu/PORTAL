export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Admin Dashboard</h1>
      <div className="card p-6">
        <div className="text-sm font-extrabold">Modul Admin (MVP)</div>
        <ul className="mt-3 space-y-2 text-sm text-neutral-700">
          <li>• CRUD Event + publish</li>
          <li>• Lihat peserta per event</li>
          <li>• Konten lain (berita/beasiswa/donasi) dapat ditambahkan setelah MVP</li>
        </ul>
      </div>
    </div>
  );
}
