import { prisma } from "@/lib/db/prisma";

export const dynamic = "force-dynamic";

export default async function AchievementsPage() {
  const items = await prisma.achievement.findMany({
    where: { isPublished: true },
    orderBy: [{ year: "desc" }, { createdAt: "desc" }],
    select: { title: true, description: true, year: true, memberName: true, mediaUrl: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Prestasi Anggota</h1>
      <div className="grid gap-4 md:grid-cols-2">
        {items.map((a, idx) => (
          <div key={idx} className="card p-6">
            <div className="text-xs text-neutral-500">{a.year} {a.memberName ? `• ${a.memberName}` : ""}</div>
            <div className="mt-2 text-lg font-extrabold">{a.title}</div>
            <p className="mt-2 text-sm text-neutral-600 whitespace-pre-wrap">{a.description}</p>
            {a.mediaUrl ? <a className="mt-3 inline-block text-sm underline" href={a.mediaUrl}>Lihat Media</a> : null}
          </div>
        ))}
        {items.length === 0 ? <div className="muted">Belum ada prestasi yang dipublikasikan.</div> : null}
      </div>
    </div>
  );
}
