import { prisma } from "@/lib/db/prisma";
import { notFound } from "next/navigation";
import EventRegisterButton from "@/components/forms/EventRegisterButton";

export const dynamic = "force-dynamic";

export default async function EventDetail({ params }: { params: { slug: string } }) {
  const event = await prisma.event.findUnique({
    where: { slug: params.slug },
    select: {
      id: true,
      title: true,
      description: true,
      location: true,
      dateStart: true,
      dateEnd: true,
      quota: true,
      isPublished: true
    }
  });

  if (!event || !event.isPublished) return notFound();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <h1 className="text-3xl font-black">{event.title}</h1>
      <div className="text-sm text-neutral-600">
        {new Date(event.dateStart).toLocaleString()} {event.dateEnd ? `– ${new Date(event.dateEnd).toLocaleString()}` : ""} • {event.location || "TBA"} • Kuota: {event.quota}
      </div>

      <div className="card p-6">
        <div className="text-sm font-bold">Deskripsi</div>
        <p className="mt-2 text-sm text-neutral-700 whitespace-pre-wrap">{event.description}</p>

        <div className="mt-6 rounded-xl border border-neutral-200 bg-neutral-50 p-4 text-sm text-neutral-700">
          Pendaftaran hanya untuk anggota. Silakan login untuk mendaftar.
        </div>

        <div className="mt-4">
          <EventRegisterButton eventId={event.id} />
        </div>
      </div>
    </div>
  );
}
