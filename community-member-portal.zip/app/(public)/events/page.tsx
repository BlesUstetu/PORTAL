import { prisma } from "@/lib/db/prisma";
import { EventCard } from "@/components/EventCard";

export const dynamic = "force-dynamic";

export default async function EventsPage() {
  const events = await prisma.event.findMany({
    where: { isPublished: true },
    orderBy: { dateStart: "asc" },
    select: { id: true, title: true, slug: true, dateStart: true, location: true, quota: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Acara</h1>
      <p className="text-sm text-neutral-600">
        Pendaftaran acara hanya untuk anggota (member-only). Publik tetap bisa melihat detail acara.
      </p>

      <div className="grid gap-4">
        {events.map((e) => <EventCard key={e.id} event={e} />)}
        {events.length === 0 ? <div className="muted">Belum ada acara.</div> : null}
      </div>
    </div>
  );
}
