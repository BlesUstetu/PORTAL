import Link from "next/link";
import { prisma } from "@/lib/db/prisma";

export const dynamic = "force-dynamic";

export default async function DonationsPage() {
  const campaigns = await prisma.donationCampaign.findMany({
    where: { isActive: true },
    orderBy: { createdAt: "desc" },
    select: { title: true, slug: true, targetAmount: true, collectedAmount: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Donasi</h1>
      <p className="text-sm text-neutral-600">
        Dukungan Anda membantu program komunitas berjalan. Saat ini metode donasi: transfer manual + konfirmasi.
      </p>
      <div className="grid gap-4">
        {campaigns.map((c) => {
          const pct = c.targetAmount > 0 ? Math.min(100, Math.round((c.collectedAmount / c.targetAmount) * 100)) : 0;
          return (
            <div key={c.slug} className="card p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-lg font-extrabold">{c.title}</div>
                  <div className="mt-1 text-sm text-neutral-600">
                    Terkumpul: {c.collectedAmount} / Target: {c.targetAmount} ({pct}%)
                  </div>
                </div>
                <Link href={`/donations/${c.slug}`} className="btn btn-primary">Donasi</Link>
              </div>
            </div>
          );
        })}
        {campaigns.length === 0 ? <div className="muted">Belum ada campaign donasi.</div> : null}
      </div>
    </div>
  );
}
