"use client";

import { useEffect, useState } from "react";

export default function DonationDetail({ params }: { params: { slug: string } }) {
  const [campaign, setCampaign] = useState<any>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch(`/api/donations/${params.slug}`).then(r => r.json()).then(d => setCampaign(d.campaign));
  }, [params.slug]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);

    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch(`/api/donations/${params.slug}/submit`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok) {
      setMsg(data?.error || "Gagal mengirim konfirmasi");
      setLoading(false);
      return;
    }

    setMsg("Konfirmasi terkirim. Tim akan memverifikasi.");
    setLoading(false);
    (e.target as HTMLFormElement).reset();
  }

  if (!campaign) return <div className="muted">Memuat...</div>;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-black">{campaign.title}</h1>
      <div className="card p-6 space-y-3">
        <p className="text-sm text-neutral-700 whitespace-pre-wrap">{campaign.description}</p>
        <div className="text-sm text-neutral-600">
          Transfer manual ke rekening/QR organisasi (isi di admin/README).
        </div>
        <div className="text-xs text-neutral-500">
          Target: {campaign.targetAmount} • Terkumpul: {campaign.collectedAmount}
        </div>
      </div>

      <div className="card p-6">
        <div className="text-sm font-extrabold">Form Konfirmasi Donasi</div>
        <form onSubmit={onSubmit} className="mt-4 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="label mb-1">Nama (opsional)</div>
              <input className="input" name="donorName" />
            </div>
            <div>
              <div className="label mb-1">Email (opsional)</div>
              <input className="input" type="email" name="email" />
            </div>
            <div>
              <div className="label mb-1">Nominal *</div>
              <input className="input" name="amount" type="number" min="1" required />
            </div>
            <div>
              <div className="label mb-1">Metode</div>
              <select className="input" name="paymentMethod">
                <option value="MANUAL">Transfer Manual</option>
              </select>
            </div>
          </div>

          <button disabled={loading} className="btn btn-primary w-full">
            {loading ? "Mengirim..." : "Kirim Konfirmasi"}
          </button>
          {msg ? <div className="text-sm text-neutral-700">{msg}</div> : null}
          <p className="text-xs text-neutral-500">
            Status default: PENDING sampai admin konfirmasi.
          </p>
        </form>
      </div>
    </div>
  );
}
