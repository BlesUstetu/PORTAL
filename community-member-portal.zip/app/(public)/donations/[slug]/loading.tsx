export default function Loading(){return <div className='muted'>Memuat...</div>}
