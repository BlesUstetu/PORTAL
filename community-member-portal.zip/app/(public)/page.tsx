import Link from "next/link";
import { site } from "@/lib/site";

export default function HomePage() {
  return (
    <div className="space-y-10">
      <section className="card p-8 md:p-10">
        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div className="space-y-4">
            <h1 className="text-3xl font-black tracking-tight md:text-4xl">
              {site.organizationName}
            </h1>
            <p className="text-neutral-700">{site.tagline}</p>
            <div className="flex flex-wrap gap-3">
              <Link href="/join" className="btn btn-primary">Daftar Anggota</Link>
              <Link href="/events" className="btn btn-outline">Lihat Acara</Link>
              <Link href="/donations" className="btn btn-outline">Donasi</Link>
            </div>
            <p className="text-xs text-neutral-500">
              Catatan: pendaftaran acara hanya untuk anggota (member-only).
            </p>
          </div>
          <div className="card p-6">
            <div className="text-sm font-bold">Fokus Portal</div>
            <ul className="mt-3 space-y-2 text-sm text-neutral-700">
              <li>• Berita & pembaruan komunitas</li>
              <li>• Detail acara + pendaftaran member-only</li>
              <li>• Prestasi anggota</li>
              <li>• Beasiswa + aplikasi</li>
              <li>• Donasi & peluang kontribusi</li>
              <li>• Login anggota yang aman</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <div className="card p-6">
          <div className="text-sm font-extrabold">Berbagi Informasi</div>
          <p className="mt-2 text-sm text-neutral-600">
            Publikasikan berita, pembaruan, detail acara, prestasi, beasiswa, dan donasi.
          </p>
          <Link href="/news" className="mt-4 inline-block text-sm underline">Buka Berita</Link>
        </div>
        <div className="card p-6">
          <div className="text-sm font-extrabold">Keterlibatan</div>
          <p className="mt-2 text-sm text-neutral-600">
            Registrasi event khusus anggota + riwayat pendaftaran di dashboard.
          </p>
          <Link href="/events" className="mt-4 inline-block text-sm underline">Buka Acara</Link>
        </div>
        <div className="card p-6">
          <div className="text-sm font-extrabold">Perekrutan Anggota</div>
          <p className="mt-2 text-sm text-neutral-600">
            Form pendaftaran anggota langsung aktif, dengan login aman.
          </p>
          <Link href="/join" className="mt-4 inline-block text-sm underline">Daftar Anggota</Link>
        </div>
      </section>
    </div>
  );
}
