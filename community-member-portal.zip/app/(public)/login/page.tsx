import LoginForm from "@/components/forms/LoginForm";
import Link from "next/link";

export default function LoginPage() {
  return (
    <div className="mx-auto max-w-md space-y-6">
      <h1 className="text-2xl font-black">Login Anggota</h1>
      <p className="text-sm text-neutral-600">
        Gunakan email dan password yang Anda daftarkan.
      </p>
      <div className="card p-6">
        <LoginForm />
      </div>
      <p className="text-sm text-neutral-600">
        Belum punya akun? <Link className="underline" href="/join">Daftar anggota</Link>
      </p>
    </div>
  );
}
