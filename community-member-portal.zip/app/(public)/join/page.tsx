import JoinForm from "@/components/forms/JoinForm";

export default function JoinPage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-black">Pendaftaran Anggota</h1>
      <p className="text-sm text-neutral-600">
        Isi data berikut. Keanggotaan langsung aktif setelah pendaftaran berhasil.
      </p>
      <div className="card p-6">
        <JoinForm />
      </div>
    </div>
  );
}
