import { prisma } from "@/lib/db/prisma";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function NewsDetail({ params }: { params: { slug: string } }) {
  const post = await prisma.newsPost.findUnique({
    where: { slug: params.slug },
    select: { title: true, content: true, publishedAt: true, category: true, isPublished: true }
  });

  if (!post || !post.isPublished) return notFound();

  return (
    <article className="mx-auto max-w-3xl space-y-4">
      <div className="text-xs text-neutral-500">
        {post.category || "Update"} • {post.publishedAt ? new Date(post.publishedAt).toLocaleString() : "-"}
      </div>
      <h1 className="text-3xl font-black">{post.title}</h1>
      <div className="card p-6">
        <div className="prose max-w-none">
          <p className="text-sm text-neutral-800 whitespace-pre-wrap">{post.content}</p>
        </div>
      </div>
    </article>
  );
}
