import Link from "next/link";
import { prisma } from "@/lib/db/prisma";

export const dynamic = "force-dynamic";

export default async function NewsPage() {
  const posts = await prisma.newsPost.findMany({
    where: { isPublished: true },
    orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
    select: { title: true, slug: true, excerpt: true, publishedAt: true, category: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Berita & Pembaruan</h1>

      <div className="grid gap-4">
        {posts.map((p) => (
          <Link key={p.slug} href={`/news/${p.slug}`} className="card p-6 hover:bg-neutral-50">
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span>{p.category || "Update"}</span>
              <span>•</span>
              <span>{p.publishedAt ? new Date(p.publishedAt).toLocaleDateString() : "-"}</span>
            </div>
            <div className="mt-2 text-lg font-extrabold">{p.title}</div>
            <div className="mt-2 text-sm text-neutral-600">{p.excerpt || "Baca selengkapnya..."}</div>
          </Link>
        ))}
        {posts.length === 0 ? <div className="muted">Belum ada berita.</div> : null}
      </div>
    </div>
  );
}
