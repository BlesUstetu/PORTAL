"use client";

import { useState } from "react";

export default function ApplyScholarship({ params }: { params: { slug: string } }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);

    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch(`/api/scholarships/${params.slug}/apply`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok) {
      setMsg(data?.error || "Gagal mengirim aplikasi");
      setLoading(false);
      return;
    }

    setMsg("Aplikasi berhasil dikirim. Tim akan memproses.");
    setLoading(false);
    (e.target as HTMLFormElement).reset();
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-black">Form Aplikasi Beasiswa</h1>
      <div className="card p-6">
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="label mb-1">Nama lengkap *</div>
              <input className="input" name="applicantName" required />
            </div>
            <div>
              <div className="label mb-1">Email *</div>
              <input className="input" type="email" name="email" required />
            </div>
            <div>
              <div className="label mb-1">No HP *</div>
              <input className="input" name="phone" required />
            </div>
            <div>
              <div className="label mb-1">Tanggal lahir (opsional)</div>
              <input className="input" type="date" name="dateOfBirth" />
            </div>
            <div>
              <div className="label mb-1">Kota (opsional)</div>
              <input className="input" name="city" />
            </div>
            <div className="md:col-span-2">
              <div className="label mb-1">Alamat (opsional)</div>
              <input className="input" name="address" />
            </div>
            <div className="md:col-span-2">
              <div className="label mb-1">Catatan (opsional)</div>
              <textarea className="input" name="notes" rows={4} />
            </div>
          </div>

          <button disabled={loading} className="btn btn-primary w-full">
            {loading ? "Mengirim..." : "Kirim Aplikasi"}
          </button>
          {msg ? <div className="text-sm text-neutral-700">{msg}</div> : null}
          <p className="text-xs text-neutral-500">
            Upload dokumen dapat ditambahkan kemudian (S3/Cloudinary). Saat ini form menyimpan data aplikasi.
          </p>
        </form>
      </div>
    </div>
  );
}
