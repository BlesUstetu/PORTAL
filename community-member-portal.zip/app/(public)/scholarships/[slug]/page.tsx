import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function ScholarshipDetail({ params }: { params: { slug: string } }) {
  const s = await prisma.scholarship.findUnique({
    where: { slug: params.slug },
    select: { id: true, title: true, requirements: true, isOpen: true, periodStart: true, periodEnd: true, slug: true }
  });
  if (!s) return notFound();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="text-xs text-neutral-500">
        Periode: {new Date(s.periodStart).toLocaleDateString()} – {new Date(s.periodEnd).toLocaleDateString()} • {s.isOpen ? "OPEN" : "CLOSED"}
      </div>
      <h1 className="text-3xl font-black">{s.title}</h1>
      <div className="card p-6">
        <div className="text-sm font-bold">Persyaratan</div>
        <p className="mt-2 text-sm text-neutral-700 whitespace-pre-wrap">{s.requirements}</p>
      </div>
      <div className="flex gap-3">
        <Link href={`/scholarships/${s.slug}/apply`} className={`btn ${s.isOpen ? "btn-primary" : "btn-outline"}`}>
          Ajukan Beasiswa
        </Link>
        <Link href="/scholarships" className="btn btn-outline">Kembali</Link>
      </div>
    </div>
  );
}
