import Link from "next/link";
import { prisma } from "@/lib/db/prisma";

export const dynamic = "force-dynamic";

export default async function ScholarshipsPage() {
  const items = await prisma.scholarship.findMany({
    orderBy: { periodStart: "desc" },
    select: { title: true, slug: true, isOpen: true, periodStart: true, periodEnd: true }
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">Beasiswa</h1>
      <div className="grid gap-4">
        {items.map((s) => (
          <div key={s.slug} className="card p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-lg font-extrabold">{s.title}</div>
                <div className="mt-1 text-sm text-neutral-600">
                  Periode: {new Date(s.periodStart).toLocaleDateString()} – {new Date(s.periodEnd).toLocaleDateString()}
                </div>
                <div className="mt-1 text-xs text-neutral-500">{s.isOpen ? "OPEN" : "CLOSED"}</div>
              </div>
              <Link href={`/scholarships/${s.slug}`} className="btn btn-outline">Detail</Link>
            </div>
          </div>
        ))}
        {items.length === 0 ? <div className="muted">Belum ada program beasiswa.</div> : null}
      </div>
    </div>
  );
}
