import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";

export async function POST(req: Request, { params }: { params: { slug: string } }) {
  try {
    const body = await req.json();

    const scholarship = await prisma.scholarship.findUnique({
      where: { slug: params.slug },
      select: { id: true, isOpen: true }
    });

    if (!scholarship) return NextResponse.json({ error: "Scholarship not found" }, { status: 404 });
    if (!scholarship.isOpen) return NextResponse.json({ error: "Scholarship closed" }, { status: 410 });

    const applicantName = String(body.applicantName || "").trim();
    const email = String(body.email || "").toLowerCase().trim();
    const phone = String(body.phone || "").trim();

    if (!applicantName || !email || !phone) {
      return NextResponse.json({ error: "Field wajib belum lengkap" }, { status: 400 });
    }

    await prisma.scholarshipApplication.create({
      data: {
        scholarshipId: scholarship.id,
        applicantName,
        email,
        phone,
        city: body.city ? String(body.city).trim() : null,
        address: body.address ? String(body.address).trim() : null,
        dateOfBirth: body.dateOfBirth ? new Date(String(body.dateOfBirth)) : null,
        notes: body.notes ? String(body.notes).trim() : null,
        status: "PENDING"
      }
    });

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
