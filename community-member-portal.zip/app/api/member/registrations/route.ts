import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/options";
import { prisma } from "@/lib/db/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  const user = (session as any)?.user;
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const registrations = await prisma.eventRegistration.findMany({
    where: { userId: user.id, status: "REGISTERED" },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      createdAt: true,
      event: { select: { id: true, title: true, slug: true, dateStart: true, location: true } }
    }
  });

  return NextResponse.json({ registrations });
}
