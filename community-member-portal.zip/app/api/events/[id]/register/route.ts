import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/options";
import { prisma } from "@/lib/db/prisma";

export async function POST(_: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const user = (session as any)?.user;

  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (user.status !== "ACTIVE") return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const eventId = params.id;

  const event = await prisma.event.findUnique({
    where: { id: eventId },
    select: { id: true, quota: true, isPublished: true, dateStart: true }
  });

  if (!event || !event.isPublished) return NextResponse.json({ error: "Event not found" }, { status: 404 });

  const registeredCount = await prisma.eventRegistration.count({
    where: { eventId, status: "REGISTERED" }
  });

  if (registeredCount >= event.quota) {
    return NextResponse.json({ error: "Quota full" }, { status: 409 });
  }

  try {
    const reg = await prisma.eventRegistration.create({
      data: { eventId, userId: user.id, status: "REGISTERED" },
      select: { id: true, status: true, createdAt: true }
    });
    return NextResponse.json({ ok: true, registration: reg }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Already registered" }, { status: 409 });
  }
}
