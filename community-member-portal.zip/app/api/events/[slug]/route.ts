import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";

export async function GET(_: Request, { params }: { params: { slug: string } }) {
  const event = await prisma.event.findUnique({
    where: { slug: params.slug },
    select: {
      id: true,
      title: true,
      slug: true,
      description: true,
      location: true,
      dateStart: true,
      dateEnd: true,
      quota: true,
      isPublished: true
    }
  });

  if (!event || !event.isPublished) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ event });
}
