import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";

export async function GET() {
  const events = await prisma.event.findMany({
    where: { isPublished: true },
    orderBy: { dateStart: "asc" },
    select: { id: true, title: true, slug: true, dateStart: true, location: true, quota: true }
  });

  return NextResponse.json({ events });
}
