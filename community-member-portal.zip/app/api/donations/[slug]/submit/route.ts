import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";

export async function POST(req: Request, { params }: { params: { slug: string } }) {
  try {
    const body = await req.json();
    const campaign = await prisma.donationCampaign.findUnique({
      where: { slug: params.slug },
      select: { id: true, isActive: true }
    });

    if (!campaign || !campaign.isActive) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Nominal tidak valid" }, { status: 400 });
    }

    await prisma.donation.create({
      data: {
        campaignId: campaign.id,
        donorName: body.donorName ? String(body.donorName).trim() : null,
        email: body.email ? String(body.email).trim() : null,
        amount,
        paymentMethod: body.paymentMethod ? String(body.paymentMethod) : "MANUAL",
        status: "PENDING"
      }
    });

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
