import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";

export async function GET(_: Request, { params }: { params: { slug: string } }) {
  const campaign = await prisma.donationCampaign.findUnique({
    where: { slug: params.slug },
    select: { id: true, title: true, slug: true, description: true, targetAmount: true, collectedAmount: true, isActive: true }
  });

  if (!campaign || !campaign.isActive) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ campaign });
}
