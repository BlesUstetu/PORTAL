import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireAdmin } from "@/lib/auth/requireRole";
import { adminEventSchema } from "@/lib/validators/event";

export async function POST(req: Request) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "Forbidden" }, { status: auth.status });

  const body = await req.json();
  const parsed = adminEventSchema.safeParse({
    ...body,
    quota: Number(body.quota)
  });

  if (!parsed.success) {
    return NextResponse.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;

  try {
    const created = await prisma.event.create({
      data: {
        title: data.title,
        slug: data.slug,
        description: data.description,
        location: data.location || null,
        dateStart: new Date(data.dateStart),
        dateEnd: data.dateEnd ? new Date(data.dateEnd) : null,
        quota: data.quota,
        isPublished: data.isPublished
      },
      select: { id: true, title: true, slug: true }
    });

    return NextResponse.json({ ok: true, event: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Create failed (slug mungkin sudah dipakai)" }, { status: 409 });
  }
}

export async function GET() {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "Forbidden" }, { status: auth.status });

  const events = await prisma.event.findMany({
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true, slug: true, dateStart: true, quota: true, isPublished: true }
  });
  return NextResponse.json({ events });
}
