import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireAdmin } from "@/lib/auth/requireRole";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "Forbidden" }, { status: auth.status });

  const regs = await prisma.eventRegistration.findMany({
    where: { eventId: params.id, status: "REGISTERED" },
    orderBy: { createdAt: "desc" },
    select: {
      createdAt: true,
      user: { select: { fullName: true, email: true, phone: true, city: true } }
    }
  });

  return NextResponse.json({ registrations: regs });
}
