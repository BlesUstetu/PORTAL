import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireAdmin } from "@/lib/auth/requireRole";
import { adminEventSchema } from "@/lib/validators/event";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "Forbidden" }, { status: auth.status });

  const body = await req.json();
  const parsed = adminEventSchema.safeParse({
    ...body,
    quota: Number(body.quota)
  });

  if (!parsed.success) {
    return NextResponse.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;

  try {
    const updated = await prisma.event.update({
      where: { id: params.id },
      data: {
        title: data.title,
        slug: data.slug,
        description: data.description,
        location: data.location || null,
        dateStart: new Date(data.dateStart),
        dateEnd: data.dateEnd ? new Date(data.dateEnd) : null,
        quota: data.quota,
        isPublished: data.isPublished
      },
      select: { id: true, title: true, slug: true }
    });
    return NextResponse.json({ ok: true, event: updated });
  } catch {
    return NextResponse.json({ error: "Update failed" }, { status: 400 });
  }
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const auth = await requireAdmin();
  if (!auth.ok) return NextResponse.json({ error: "Forbidden" }, { status: auth.status });

  await prisma.event.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
