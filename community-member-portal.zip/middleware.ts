import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getToken } from "next-auth/jwt";

const MEMBER_PATHS = ["/member"];
const ADMIN_PATHS = ["/admin"];

export async function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

  const isMemberRoute = MEMBER_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/"));
  const isAdminRoute = ADMIN_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/"));

  if (isMemberRoute && !token) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = `next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  if (isAdminRoute) {
    if (!token) {
      const url = req.nextUrl.clone();
      url.pathname = "/login";
      url.search = `next=${encodeURIComponent(pathname + search)}`;
      return NextResponse.redirect(url);
    }
    if ((token as any).role !== "ADMIN") {
      return NextResponse.redirect(new URL("/member/dashboard", req.url));
    }
  }

  return NextResponse.next();
}

export const config = { matcher: ["/member/:path*", "/admin/:path*"] };
